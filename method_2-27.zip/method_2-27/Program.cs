﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace method_2_27
{
    class Program
    {
        static void Main(string[] args)
        {
            string name = "william";

            Change(ref name);
            Console.WriteLine(name);


            Console.ReadLine();
            
        }
        public static void Change(ref string name)
        {
            Console.WriteLine(name);
            name = "Nick";
        }
    }
}
