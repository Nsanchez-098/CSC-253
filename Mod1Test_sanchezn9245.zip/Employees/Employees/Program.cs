﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/**
 * Nicholas Sanchez
 * 2/10
 * (CSC-153-0001)
 * Program to display employee information
 */
namespace Employees
{
    class Program
    {


        static void Main(string[] args)
        {
            //create inpt var for user input and sentry for loop
            string input;
            bool exit = false;
            //create constant var
            const int SIZE = 5;

            int nameIndex = 0, phoneIndex = 0;

            string[] employeeNames = new string[SIZE];
            string[] employeePhone = new string[SIZE];
            List<int> employeeAge = new List<int>();

            do
            {
                Console.WriteLine("1. Enter employee's name.");
                Console.WriteLine("2. Enter employee's Phone number.");
                Console.WriteLine("3. Enter employee's age.");
                Console.WriteLine("4. Display employee's information");
                Console.WriteLine("5. Display average age of employee");
                Console.WriteLine("6. Exit");
                Console.Write("--->");
                Console.WriteLine("");
                input = Console.ReadLine();

                //Switch to direct to proper process
                switch(input)
                {
                    case "1":
                        Console.Write("Enter employee name -> ");
                        input = Console.ReadLine();
                        employeeNames[nameIndex] = input;
                        nameIndex++;
                        Console.WriteLine("");
                        break;
                    case "2":
                        Console.Write("Enter employee's Phone number -> ");
                        input = Console.ReadLine();
                        employeePhone[phoneIndex] = input;
                        phoneIndex++;
                        Console.WriteLine("");
                        break;
                    case "3":
                        int number = 0;
                        Console.Write("Enter employeess age -> ");
                        input = Console.ReadLine();
                        Console.WriteLine("");
                        if (int.TryParse(input, out number))
                        {
                            employeeAge.Add(number);
                            Console.WriteLine("");
                        }
                        else
                        {

                        }
                        break;
                    case "4":
                        for(int index = 0; index < employeeAge.Count; index++)
                        {
                            Console.WriteLine($"employee name - { employeeNames[index]}");
                            Console.WriteLine($"Employee Phone - {employeePhone[index]}");
                            Console.WriteLine($"Employee Age - {employeeAge[index]}");
                            Console.WriteLine("");
                        }
                        break;
                    case "5":
                        Console.WriteLine(employeeAge.Average());
                        Console.WriteLine("");
                        break;
                    case "6":
                        exit = true;
                        break;
                    default:
                        Console.WriteLine("Not a valid number!");
                        break;
                }
            } while (exit == false);
        }
    }
}
