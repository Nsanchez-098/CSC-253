﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/**
* 2/17/2020
* CSC 153
* Nicholas Sanchez
* Utilizing an array to display sales prices
*/

namespace TotalSalesHardCoded
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] salesDisplay = new string[] { "1245.67", "1189.55", "1098.72", "1456.88", "2109.34", "1987.55", "1872.36" };
            Console.ReadLine();
        }
    }
}
